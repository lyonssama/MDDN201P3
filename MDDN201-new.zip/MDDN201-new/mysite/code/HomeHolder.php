<?php
class HomeHolder extends Page {

	// private static $allowed_children = array (
	// 	'portfolioPage'
	// );

	private static $db = array(
	);

	private static $has_one = array(
	);

}
class HomeHolder_Controller extends Page_Controller {


}
