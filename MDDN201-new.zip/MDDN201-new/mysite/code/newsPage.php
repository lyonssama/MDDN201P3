<?php

class newsPage extends Page {

  private static $db = array (
    'Event' => 'Varchar',
    'Date' => 'Date',

  );

  // private static $has_one = array (
  //   'File' => 'File'
  // );

  public function getCMSFields() {
    $fields = parent::getCMSFields();
    $fields->addFieldToTab('Root.Main', TextField::create('Event','Event'),'Content');
    $fields->addFieldToTab('Root.Main', DateField::create('Date','Date')->setConfig('showcalendar', true),'Content');




    return $fields;
  }

}

class newsPage_Controller extends Page_Controller {

}
