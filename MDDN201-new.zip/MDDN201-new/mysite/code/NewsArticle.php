<?php

class NewsArticle extends Page {

  private static $db = array (
    'ArticleTitle' => 'Text',
    'Date' => 'Date',
    'Teaser' => 'Varchar'

  );

  private static $has_one = array (
            'SingleImage' => 'Image'
        );

  public function getCMSFields() {
    $fields = parent::getCMSFields();
    $fields->addFieldToTab('Root.Main', TextareaField::create('ArticleTitle'),'Content');
    $fields->addFieldToTab('Root.Main', DateField::create('Date','Date')->setConfig('showcalendar', true),'Content');
    $fields->addFieldToTab('Root.Main', TextareaField::create('Teaser'),'Content');
    $fields->addFieldToTab('Root.Upload', UploadField::create('SingleImage', 'Upload Image'));

    return $fields;
  }

}

class NewsArticle_Controller extends Page_Controller {

}
