<?php  phpinfo();  ?>

