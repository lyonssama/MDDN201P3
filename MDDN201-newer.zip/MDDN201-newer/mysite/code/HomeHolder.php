<?php
class HomeHolder extends Page {

	// private static $allowed_children = array (
	// 	'portfolioPage'
	// );

	private static $db = array(
	);

	private static $has_one = array(
	);

}
class HomeHolder_Controller extends Page_Controller {

	public function getProjectIcons()
	{
		$list = new ArrayList();

		$files = array(
			"$themeDir/img/dep_logo_fyd_sm.png",
			"$themeDir/img/dep_logo_ind_sm.png",
			"$themeDir/img/dep_logo_cc_sm.png",
			"$themeDir/img/dep_logo_mdi_sm.png",
			"$themeDir/img/dep_logo_media_sm.png",
		);

		foreach ($files as $file) {
			$list->push(new ArrayData(array(
				'File' => $file
			)));
		}

		return $list;
	}


}
