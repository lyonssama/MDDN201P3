<?php

class CourseInfo extends Page {

  private static $db = array (
    'CourseCode' => 'Varchar',
    'PaperName' => 'Varchar',
    'Lecturer' => 'Varchar',
    'Teaser' => 'Text',


  );

  private static $has_one = array (
    'SingleImage' => 'Image'

  );

  public function getCMSFields() {
    $fields = parent::getCMSFields();
    $fields->addFieldToTab('Root.Main', TextField::create('CourseCode','Course Code'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('PaperName','Paper Name'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('Lecturer','Lecturer'),'Content');
    $fields->addFieldToTab('Root.Main', TextareaField::create('Teaser'),'Content');
    $fields->addFieldToTab('Root.Upload', UploadField::create('SingleImage', 'Upload Image'));



    return $fields;
  }

}

class CourseInfo_Controller extends Page_Controller {

}
