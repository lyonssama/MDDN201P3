<?php

class NewsArticle extends Page {

  private static $types = array(
    'FirstYear' => 'First Year',
    'Media' => 'Media',
    'Industrial' => 'Idustrial',
    'CultureContext' => 'CultureContext',
    'Masters' => 'Masters'
  );


  private static $db = array (
    'ArticleTitle' => 'Text',
    'Date' => 'Date',
    'Teaser' => 'Varchar',
    "Options" => "Enum('FirstYear,Media,Industrial,CultureContext,Masters', 'Media')"

  );

  private static $has_one = array (
            'SingleImage' => 'Image'
        );

  public function getCMSFields() {
    $fields = parent::getCMSFields();
    $fields->addFieldToTab('Root.Main', TextareaField::create('ArticleTitle'),'Content');
    $fields->addFieldToTab('Root.Main', DateField::create('Date','Date')->setConfig('showcalendar', true),'Content');
    $fields->addFieldToTab("Root.Main", DropdownField::create('Options', 'Choose an option', $this->dbObject('Options')->enumValues()), 'Content');
    $fields->addFieldToTab('Root.Main', TextareaField::create('Teaser'),'Content');
    $fields->addFieldToTab('Root.Upload', UploadField::create('SingleImage', 'Upload Image'));

    return $fields;
  }

  public function getIcon() {
    $themeDir = Controller::curr()->ThemeDir();

    switch($this->Options) {
      case 'FirstYear':
        return "$themeDir/img/dep_logo_fyd_sm.png";
      case 'Industrial':
        return "$themeDir/img/dep_logo_ind_sm.png";
      case 'CultureContext':
        return "$themeDir/img/dep_logo_cc_sm.png";
      case 'Masters':
        return "$themeDir/img/dep_logo_mdi_sm.png";
      case 'Media':
        return "$themeDir/img/dep_logo_media_sm.png";
      default:
        return '';
    }
  }

}

class NewsArticle_Controller extends Page_Controller {

}
