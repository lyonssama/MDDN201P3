<?php
class HomeHolder extends Page {

	// private static $allowed_children = array (
	// 	'portfolioPage'
	// );

	private static $db = array(
	);

	private static $has_one = array(
	);


}
class HomeHolder_Controller extends Page_Controller {

	public function getProjects()
	{
		// get the GET filter parameter
		$filter = $this->getRequest()->getVar('filter');

		$projects = portfolioPage::get();

		if ($filter) {
			$projects = $projects->filter('Options', $filter);
		}

		return $projects;
	}

}
