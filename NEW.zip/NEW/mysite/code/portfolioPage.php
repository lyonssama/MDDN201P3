<?php

class portfolioPage extends Page {



  private static $types = array(
    'FirstYear' => 'First Year',
    'Media' => 'Media',
    'Industrial' => 'Idustrial',
    'CultureContext' => 'CultureContext',
    'Masters' => 'Masters'
  );

  private static $db = array (
    'Title' => 'Varchar',
    'Designer' => 'Varchar',
    'Type' => 'Text',
    'Lecturer' => 'Varchar',
    'Paper' => 'Varchar',
    'Date' => 'Date',
    'Teaser' => 'Text',
    'LinkOne' => 'Varchar',
    'LinkTwo' => 'Varchar',
    'LinkThree' => 'Varchar',
    "Options" => "Enum('FirstYear,Media,Industrial,CultureContext,Masters', 'Media')"

    // 'Tags' => 'Varchar',
    // 'Download' => 'Varchar',

  );

  private static $has_one = array (
    'File' => 'File',
    'Images' => 'Image'
  );

  public function getIconPath() {
    $themeDir = Controller::curr()->ThemeDir();

    switch($this->Options) {
      case 'FirstYear':
        return "$themeDir/img/dep_logo_fyd_sm.png";
      case 'Industrial':
        return "$themeDir/img/dep_logo_ind_sm.png";
      case 'CultureContext':
        return "$themeDir/img/dep_logo_cc_sm.png";
      case 'Masters':
        return "$themeDir/img/dep_logo_mdi_sm.png";
      case 'Media':
        return "$themeDir/img/dep_logo_media_sm.png";
      default:
        return '';
    }
  }

  public function getCMSFields() {
    $fields = parent::getCMSFields();
    $fields->addFieldToTab('Root.Main', TextField::create('Title','Project Title'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('Designer','Designer'),'Content');
    $fields->addFieldToTab("Root.Main", DropdownField::create('Options', 'Choose an option', $this->dbObject('Options')->enumValues()), 'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('Lecturer','Lecturer for the Project'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('Paper','Paper'),'Content');
    $fields->addFieldToTab('Root.Main', DateField::create('Date','Date')->setConfig('showcalendar', true),'Content');
    $fields->addFieldToTab('Root.Main', TextareaField::create('Teaser'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('LinkOne','Project Link One'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('LinkTwo','Project Link Two'),'Content');
    $fields->addFieldToTab('Root.Main', TextField::create('LinkThree','Project Link Three'),'Content');
    // $fields->addFieldToTab('Root.Main', TextField::create('Tags','Tags'),'Content');
    // $fields->addFieldToTab('Root.Main', TextField::create('Download','Download'),'Content');
    $fields->addFieldToTab('Root.Attachments', UploadField::create('File', 'File (PDF only)'));
    $fields->addFieldToTab('Root.Upload', UploadField::create('Images', 'Upload Image'));



    return $fields;
  }

}

class portfolioPage_Controller extends Page_Controller {


}
